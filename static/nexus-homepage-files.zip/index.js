import http from "node:http";
import path from "node:path";
import { createBareServer } from "@nebula-services/bare-server-node";
import chalk from "chalk";
import cookieParser from "cookie-parser";
import cors from "cors";
import express from "express";
import basicAuth from "express-basic-auth";
import mime from "mime";
import fetch from "node-fetch";
import dotenv from "dotenv";
import config from "./config.js";

dotenv.config();
console.log(chalk.yellow("🚀 Starting NEXUS server..."));

const __dirname = process.cwd();
const server = http.createServer();
const app = express();
const bareServer = createBareServer("/fq/");
const PORT = process.env.PORT || 8080;
const cache = new Map();
const CACHE_TTL = 30 * 24 * 60 * 60 * 1000;
const searchCache = new Map();
const SEARCH_CACHE_TTL = 5 * 60 * 1000;

if (config.challenge !== false) {
  console.log(chalk.green("🔒 Password protection is enabled."));
  app.use(basicAuth({ users: config.users, challenge: true }));
}

function decodeXml(value = "") {
  return value
    .replace(/^<!\[CDATA\[([\s\S]*?)\]\]>$/, "$1")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([\da-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)));
}
function xmlField(source, name) {
  const match = source.match(new RegExp("<" + name + "(?:\\s[^>]*)?>([\\s\\S]*?)</" + name + ">", "i"));
  return match ? decodeXml(match[1]).replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim() : "";
}

app.get("/api/search", async (req, res) => {
  const query = String(req.query.q || "").trim().slice(0, 160);
  if (!query) return res.status(400).json({ error: "Enter something to search." });

  const cacheKey = query.toLowerCase();
  const cached = searchCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < SEARCH_CACHE_TTL) {
    return res.json({ query, results: cached.results, cached: true });
  }

  try {
    const endpoint = "https://www.bing.com/search?format=rss&q=" + encodeURIComponent(query);
    const upstream = await fetch(endpoint, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; NEXUSSearch/1.0)",
        "Accept": "application/rss+xml, application/xml, text/xml"
      }
    });
    if (!upstream.ok) throw new Error("The search provider returned an error.");
    const xml = await upstream.text();
    const items = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/gi)].slice(0, 10);
    const results = items.map(([_, item]) => {
      const url = xmlField(item, "link");
      let displayUrl = "";
      try { displayUrl = new URL(url).hostname; } catch {}
      return {
        title: xmlField(item, "title"),
        url,
        displayUrl,
        description: xmlField(item, "description")
      };
    }).filter(item => /^https?:\/\//i.test(item.url));

    searchCache.set(cacheKey, { results, timestamp: Date.now() });
    res.json({ query, results });
  } catch (error) {
    console.error("Search request failed:", error.message);
    res.status(502).json({ error: "Web search is temporarily unavailable. Please try again." });
  }
});

app.get("/e/*", async (req, res, next) => {
  try {
    if (cache.has(req.path)) {
      const { data, contentType, timestamp } = cache.get(req.path);
      if (Date.now() - timestamp > CACHE_TTL) cache.delete(req.path);
      else {
        res.writeHead(200, { "Content-Type": contentType });
        return res.end(data);
      }
    }
    const baseUrls = {
      "/e/1/": "https://raw.githubusercontent.com/qrs/x/fixy/",
      "/e/2/": "https://raw.githubusercontent.com/3v1/V5-Assets/main/",
      "/e/3/": "https://raw.githubusercontent.com/3v1/V5-Retro/master/"
    };
    let reqTarget;
    for (const [prefix, baseUrl] of Object.entries(baseUrls)) {
      if (req.path.startsWith(prefix)) {
        reqTarget = baseUrl + req.path.slice(prefix.length);
        break;
      }
    }
    if (!reqTarget) return next();
    const asset = await fetch(reqTarget);
    if (!asset.ok) return next();
    const data = Buffer.from(await asset.arrayBuffer());
    const ext = path.extname(reqTarget);
    const contentType = ext === ".unityweb" ? "application/octet-stream" : (mime.getType(ext) || "application/octet-stream");
    cache.set(req.path, { data, contentType, timestamp: Date.now() });
    res.writeHead(200, { "Content-Type": contentType });
    res.end(data);
  } catch (error) {
    console.error("Error fetching asset:", error);
    res.status(500).send("Error fetching the asset");
  }
});

app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get("/api/themes", (_req, res) => {
  res.json({ success: true, themes: ["default", "dark", "light", "blue", "green", "purple", "red", "orange", "pink", "cyberpunk", "retro", "neon"] });
});
app.get("/api/particles", (_req, res) => {
  res.json({ success: true, particles: ["default", "bubbles", "snow", "stars", "confetti", "matrix", "fireworks"] });
});

app.use(express.static(path.join(__dirname, "static")));
app.use("/fq", cors({ origin: true }));

const routes = [
  { path: "/yz", file: "apps.html" },
  { path: "/up", file: "games.html" },
  { path: "/play.html", file: "games.html" },
  { path: "/vk", file: "settings.html" },
  { path: "/rx", file: "tabs.html" },
  { path: "/", file: "index.html" },
  { path: "/lg", file: "account.html" },
  { path: "/dracob", file: "dracob.png" }
];
routes.forEach(route => {
  app.get(route.path, (_req, res) => res.sendFile(path.join(__dirname, "static", route.file)));
});
app.use((req, res) => res.status(404).sendFile(path.join(__dirname, "static", "404.html")));
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).sendFile(path.join(__dirname, "static", "404.html"));
});

server.on("request", (req, res) => {
  if (bareServer.shouldRoute(req)) bareServer.routeRequest(req, res);
  else app(req, res);
});
server.on("upgrade", (req, socket, head) => {
  if (bareServer.shouldRoute(req)) bareServer.routeUpgrade(req, socket, head);
  else socket.end();
});
server.listen(PORT, () => console.log(chalk.green("NEXUS server running on port " + PORT)));
