const form=document.querySelector("#nx-search");
const input=document.querySelector("#nx-query");
const results=document.querySelector("#nx-results");
const viewer=document.querySelector("#nx-viewer");
const frame=document.querySelector("#nx-frame");
const viewerTitle=document.querySelector("#nx-viewer-title");
const external=document.querySelector("#nx-open-external");
function showStatus(message){results.replaceChildren();const p=document.createElement("p");p.className="nx-status";p.textContent=message;results.append(p)}
function safeUrl(value){try{const u=new URL(value);return u.protocol==="https:"||u.protocol==="http:"?u.href:null}catch{return null}}
function openResult(url,title){const safe=safeUrl(url);if(!safe)return;viewerTitle.textContent=title||safe;external.href=safe;frame.src=safe;viewer.classList.add("show");viewer.setAttribute("aria-hidden","false")}
function closeViewer(){viewer.classList.remove("show");viewer.setAttribute("aria-hidden","true");frame.src="about:blank"}
document.querySelector("#nx-close-viewer").addEventListener("click",closeViewer);
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeViewer()});
form.addEventListener("submit",async e=>{
 e.preventDefault();const q=input.value.trim();if(!q)return;showStatus("Searching the web…");
 try{
  const response=await fetch("/api/search?"+new URLSearchParams({q}).toString(),{headers:{Accept:"application/json"}});
  const data=await response.json();if(!response.ok)throw new Error(data.error||"Search is temporarily unavailable.");
  results.replaceChildren();const heading=document.createElement("p");heading.className="nx-status";heading.textContent=data.results.length?"Results for “"+q+"”":"No results found. Try another search.";results.append(heading);
  for(const item of data.results){const url=safeUrl(item.url);if(!url)continue;const card=document.createElement("article");card.className="nx-result";const title=document.createElement("h3");title.textContent=item.title||url;const link=document.createElement("div");link.className="nx-url";link.textContent=item.displayUrl||new URL(url).hostname;const description=document.createElement("p");description.textContent=item.description||"";card.append(title,link,description);card.tabIndex=0;card.setAttribute("role","link");card.setAttribute("aria-label","Open "+(item.title||url));card.addEventListener("click",()=>openResult(url,item.title));card.addEventListener("keydown",ev=>{if(ev.key==="Enter"||ev.key===" "){ev.preventDefault();openResult(url,item.title)}});results.append(card)}
 }catch(err){showStatus(err.message||"Something went wrong. Please try again.")}
});
